﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programaFacturacion.modelo
{
    public class conexion
    {
        /*DESKTOP-Q9BG1CV\\SQLEXPRESS*/
        public string connectionString = "server=localhost;database= IshowUSpeed; integrated security= true;TrustServerCertificate=True";
    }
}
